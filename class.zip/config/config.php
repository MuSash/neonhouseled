<?php
//CONTIENE CONSTANTES PHP

//URL ABSOLUTA (ESTATICA)
define("URL", "http://veramendischicken.com/");
//define("URL", "http://localhost/polleria/");

?>