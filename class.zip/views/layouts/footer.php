
  <!-- <link rel="stylesheet" type="text/css" href="public/css/footer.css"> -->
  <footer >
  <div class="style-footer container-fluid p-5 align-self-end"  style="background-image: url(public/img/textura_de_madera_1.png);" >
  <div class="row justify-content-start footer">
      <div class="col-3  component logofooter">
      <a href="<?=URL?>main" aria-label="inicio"><img  width="150" height="110" src="..." alt="logo veramendis"></a>
      </div>
      <div class="col-3  component conocenos">
        <p class="text-white h4">Conócenos</p>
        <p class="text-white texto"> Zona de delivery</p>
        <p class=" text-white texto" > Contacto</p>
        <p class=" text-white texto"> Términos y Condiciones de Uso</p>
      </div>
      <div class="col-3  component redes">
        <p class="text-white h4">Redes Sociales</p>
        <p class=" text-white texto"> Instagram</p>
        <p class=" text-white texto"> Facebook</p>
        <p class=" text-white texto"> Tik tok</p>
      </div>
      <div class="col-3 icons">
        <div><a href="https://instagram.com/veramendischicken?utm_medium=copy_link" target="_blank"><img src="<?=URL?>public/img/contacto/instagram.svg" width="48" height="48" alt="instagram icon"/></a></div>
        <div ><a href = "https://www.facebook.com/Veramendis-Chicken-111716233585168/" target="_blank"><img src="<?=URL?>public/img/contacto/facebook.svg" width="48" height="48" alt="facebook icon"></a></div>
        <div ><a href ="https://vm.tiktok.com/ZMLMqHrjS/" target="_blank"><img src="<?=URL?>public/img/contacto/tiktok.svg"  width="48" height="48"  alt="tiktok icon"/></a></div>  

    </div>
  </div>
  </div>
  </footer>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <script src="<?=URL?>public/js/navbar.js"></script>




