<!-- <!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="<?php echo constant('URL') ?>public/css/main.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
	<style>
	body{background-image: url('fondo-textura.jpg');}
	</style>
	<div id="cabecera">
		<!-- MENU -->
		<!-- <ul>
			<li><a href="<?php echo constant('URL') ?>main">Inicio</a></li>
			<li><a href="<?php echo constant('URL') ?>consulta">Consulta</a></li>
			<li><a href="<?php echo constant('URL') ?>nuevo">Nuevo</a></li>
			<li><a href="<?php echo constant('URL') ?>ayuda">Ayuda</a></li>
		</ul>
<div class="container p-5" style="background-color: coral;" >
	<div class="row justify-content-center">
			<nav class="navbar navbar-light ">
				<a class="navbar-brand" href="#">
				<img src="/docs/4.3/assets/brand/bootstrap-solid.svg" width="30" height="30" class="d-inline-block align-top" alt="">
				Bootstrap
				</a>
				<a class="nav-item nav-link" href="#"><h2>Inicio</h2></a>
				<a class="nav-item nav-link" href="#"><h2>Promociones</h2></a>
				<a class="nav-item nav-link" href="#"><h2>Menu</h2></a>
				<a class="nav-item nav-link" href="#"><h2>Contacto</h2></a>
				
				<a class="nav-item nav-link" href="#"><button class="btn btn-primary"><h2>delivery</h2></button></a>
			</nav>
	</div>
	
		
	</div> -->

